@feature-visual @visual @regression
Feature: Visual regression

  Scenario: Login page visual baseline
    Given I navigate to the MyRetail application
    Then the login page should match the visual baseline
