@feature-inventory @ui @regression @api-setup
Feature: Inventory UI with API precondition

  Background:
    Given API test data is prepared via JSONPlaceholder
    And I am logged in as "standard_user"

  @smoke
  Scenario: View inventory after API setup
    Then I should see the products page
    And the page title should contain "Products"
