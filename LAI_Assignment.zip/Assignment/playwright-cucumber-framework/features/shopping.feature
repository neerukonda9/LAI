@feature-shopping @regression
Feature: MyRetail Shopping Cart

  @smoke
  Scenario: Add multiple products to cart using test data
    Given I am logged in as "standard_user"
    When I add cart items from test data
    Then the shopping cart badge should match test data count
