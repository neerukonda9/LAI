const { execSync } = require('child_process');
const path = require('path');

try {
  execSync('husky', {
    cwd: path.resolve(__dirname, '../..'),
    stdio: 'inherit'
  });
} catch {
  // Skip when git root is unavailable (e.g. some CI sandboxes)
}
