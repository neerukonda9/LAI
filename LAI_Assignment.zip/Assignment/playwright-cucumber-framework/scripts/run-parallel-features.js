const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const featuresDir = path.join(__dirname, '../features');
const isWindows = process.platform === 'win32';
const cucumberBin = path.join(
  __dirname,
  '../node_modules/.bin',
  isWindows ? 'cucumber-js.cmd' : 'cucumber-js'
);

function getFeatureFiles() {
  return fs
    .readdirSync(featuresDir)
    .filter((file) => file.endsWith('.feature'))
    .map((file) => path.join(featuresDir, file));
}

function runFeature(specPath) {
  return new Promise((resolve, reject) => {
    const child = spawn(cucumberBin, [specPath], {
      stdio: 'inherit',
      shell: isWindows,
      cwd: path.join(__dirname, '..'),
      env: {
        ...process.env,
        PLAYWRIGHT_BROWSERS_PATH: '0',
        NODE_OPTIONS: '-r ./scripts/load-env.js'
      }
    });

    child.on('close', (code) => {
      resolve({ specPath, success: code === 0, code });
    });

    child.on('error', reject);
  });
}

async function main() {
  const featureFiles = getFeatureFiles();

  if (featureFiles.length === 0) {
    console.error('No feature files in features/');
    process.exit(1);
  }

  const results = await Promise.all(featureFiles.map(runFeature));
  const failed = results.filter((r) => !r.success);

  results.forEach((r) => {
    console.log(`${r.success ? 'PASS' : 'FAIL'} ${path.basename(r.specPath)}`);
  });

  if (failed.length) {
    process.exit(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
