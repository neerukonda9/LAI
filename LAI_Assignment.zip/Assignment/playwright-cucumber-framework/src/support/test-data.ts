import users from '../../testdata/users.json';
import products from '../../testdata/products.json';

export type UserRecord = {
  username: string;
  password: string;
  errorMessage?: string;
};

export function getValidUser(): UserRecord {
  return users.validUser;
}

export function getLockedOutUser(): UserRecord {
  return users.lockedOutUser;
}

export function getInvalidCredentials(): Array<UserRecord & { expectedError: string }> {
  return users.invalidCredentials;
}

export function getCartItems(): Array<{ productName: string }> {
  return products.cartItems;
}

export function getExpectedCartCount(): string {
  return products.expectedCartCount;
}

export function getProductsPageTitle(): string {
  return products.pageTitle;
}

export function resolveUsername(usernameOrKey: string): string {
  const record = (users as Record<string, unknown>)[usernameOrKey];
  if (record && typeof record === 'object' && record !== null && 'username' in record) {
    return (record as UserRecord).username;
  }
  return usernameOrKey;
}
