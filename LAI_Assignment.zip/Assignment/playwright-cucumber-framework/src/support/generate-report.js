const report = require('multiple-cucumber-html-reporter');
const path = require('path');

report.generate({
  jsonDir: path.join(__dirname, '../../reports'),
  reportPath: path.join(__dirname, '../../reports/html'),
  metadata: {
    browser: { name: 'chromium', version: 'latest' },
    platform: { name: process.platform, version: process.version }
  },
  displayDuration: true,
  openReportInBrowser: false
});
