import { expect } from '@playwright/test';
import { PlaywrightWorld } from './world';

export async function loginAsUser(
  world: PlaywrightWorld,
  username: string,
  password = 'password'
): Promise<void> {
  await world.myRetailPage.open(world.baseUrl);
  await world.myRetailPage.login(username, password);
  expect(await world.myRetailPage.isProductsPageVisible()).toBeTruthy();
}
