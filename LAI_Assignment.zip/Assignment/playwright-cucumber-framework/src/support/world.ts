import { setWorldConstructor, World, IWorldOptions } from '@cucumber/cucumber';
import { Browser, BrowserContext, Page, APIRequestContext } from 'playwright';
import { MyRetailPage } from '../pages/MyRetailPage';
import { ApiClient } from '../pages/ApiClient';
import { getBaseUrl } from './env';

export interface CustomWorld extends World {
  browser: Browser;
  context: BrowserContext;
  page: Page;
  request: APIRequestContext;
  myRetailPage: MyRetailPage;
  apiClient: ApiClient;
  baseUrl: string;
  apiSetupPostId?: number;
}

class PlaywrightWorld extends World implements CustomWorld {
  browser!: Browser;
  context!: BrowserContext;
  page!: Page;
  request!: APIRequestContext;
  myRetailPage!: MyRetailPage;
  apiClient!: ApiClient;
  baseUrl = getBaseUrl();
  apiSetupPostId?: number;

  constructor(options: IWorldOptions) {
    super(options);
  }
}

setWorldConstructor(PlaywrightWorld);

export { PlaywrightWorld };
