import { Page } from 'playwright';

export type AnalyticsEvent = Record<string, unknown>;

export async function enableAnalyticsTracking(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const w = window as Window & { dataLayer?: AnalyticsEvent[] };
    w.dataLayer = w.dataLayer ?? [];
    const originalPush = w.dataLayer.push.bind(w.dataLayer);
    w.dataLayer.push = (...items: AnalyticsEvent[]) => originalPush(...items);
  });
}

export async function trackLoginSuccess(page: Page, username: string): Promise<void> {
  await page.evaluate((user) => {
    const w = window as Window & { dataLayer?: AnalyticsEvent[] };
    w.dataLayer = w.dataLayer ?? [];
    w.dataLayer.push({ event: 'login_success', user, source: 'myretail' });
  }, username);
}

export async function trackAddToCart(page: Page, productName: string): Promise<void> {
  await page.evaluate((product) => {
    const w = window as Window & { dataLayer?: AnalyticsEvent[] };
    w.dataLayer = w.dataLayer ?? [];
    w.dataLayer.push({ event: 'add_to_cart', product, source: 'myretail' });
  }, productName);
}

export async function getAnalyticsEvents(page: Page): Promise<AnalyticsEvent[]> {
  return page.evaluate(() => {
    const w = window as Window & { dataLayer?: AnalyticsEvent[] };
    return w.dataLayer ?? [];
  });
}

export async function hasAnalyticsEvent(page: Page, eventName: string): Promise<boolean> {
  const events = await getAnalyticsEvents(page);
  return events.some((event) => event.event === eventName);
}
