import { Before, After, BeforeAll, AfterAll, Status, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium, Browser } from 'playwright';
import { PlaywrightWorld } from './world';
import { MyRetailPage } from '../pages/MyRetailPage';
import { ApiClient } from '../pages/ApiClient';
import { validateEnvironment, getEnvironmentLabel, getBaseUrl } from './env';
import { enableAnalyticsTracking } from './analytics-helper';

let browser: Browser;

setDefaultTimeout(60_000);

function buildBrowserStackCaps() {
  return {
    browser: process.env.BROWSERSTACK_BROWSER || 'chrome',
    browser_version: process.env.BROWSERSTACK_BROWSER_VERSION || 'latest',
    os: process.env.BROWSERSTACK_OS || 'Windows',
    os_version: process.env.BROWSERSTACK_OS_VERSION || '11',
    'browserstack.username': process.env.BROWSERSTACK_USERNAME,
    'browserstack.accessKey': process.env.BROWSERSTACK_ACCESS_KEY,
    'browserstack.build': process.env.BROWSERSTACK_BUILD || 'playwright-cucumber',
    'browserstack.project': process.env.BROWSERSTACK_PROJECT || 'MyRetail Playwright',
    ...(process.env.BROWSERSTACK_DEVICE
      ? {
          device: process.env.BROWSERSTACK_DEVICE,
          real_mobile: process.env.BROWSERSTACK_REAL_MOBILE === 'true'
        }
      : {})
  };
}

async function launchBrowser(): Promise<Browser> {
  if (process.env.BROWSERSTACK_USERNAME && process.env.BROWSERSTACK_ACCESS_KEY) {
    const caps = buildBrowserStackCaps();
    const wsEndpoint = `wss://cdp.browserstack.com/playwright?caps=${encodeURIComponent(JSON.stringify(caps))}`;
    return chromium.connect({ wsEndpoint });
  }

  return chromium.launch({
    headless: process.env.HEADLESS !== 'false'
  });
}

BeforeAll(async function () {
  validateEnvironment();
  browser = await launchBrowser();
});

Before(async function (this: PlaywrightWorld) {
  this.browser = browser;
  this.context = await browser.newContext();
  this.page = await this.context.newPage();
  this.request = this.context.request;
  this.myRetailPage = new MyRetailPage(this.page);
  this.apiClient = new ApiClient(this.request);
  this.baseUrl = getBaseUrl();
});

Before({ tags: '@analytics' }, async function (this: PlaywrightWorld) {
  await enableAnalyticsTracking(this.page);
});

After(async function (this: PlaywrightWorld, { result, pickle }) {
  if (result?.status === Status.FAILED && this.page) {
    const screenshot = await this.page.screenshot();
    await this.attach(screenshot, 'image/png');
  }

  const durationMs = result?.duration?.nanos ? Math.round(result.duration.nanos / 1_000_000) : 0;
  await this.attach(
    JSON.stringify({
      scenario: pickle.name,
      status: result?.status,
      durationMs,
      environment: getEnvironmentLabel()
    }),
    'application/json'
  );

  await this.context?.close();
});

AfterAll(async function () {
  await browser.close();
});
