export type TestEnvironment = 'dev' | 'staging' | 'prod';

const DEFAULT_MOCK_URL = 'http://127.0.0.1:4173';

const ENV_URL_MAP: Record<TestEnvironment, string | undefined> = {
  dev: process.env.BASE_URL_DEV,
  staging: process.env.BASE_URL_STAGING ?? process.env.BASE_URL,
  prod: process.env.BASE_URL_PROD
};

export function useMockApp(): boolean {
  return process.env.USE_MOCK_APP === 'true' || process.env.USE_MOCK_APP === '1';
}

export function getMockAppUrl(): string {
  return process.env.MOCK_APP_URL ?? DEFAULT_MOCK_URL;
}

export function getTestEnvironment(): TestEnvironment {
  const env = (process.env.TEST_ENV ?? 'staging') as TestEnvironment;
  if (!['dev', 'staging', 'prod'].includes(env)) {
    throw new Error(`Invalid TEST_ENV "${env}". Use dev, staging, or prod.`);
  }
  return env;
}

export function getBaseUrl(): string {
  if (useMockApp()) {
    return getMockAppUrl();
  }

  const env = getTestEnvironment();
  const url = ENV_URL_MAP[env];

  if (!url) {
    throw new Error(`Missing URL for TEST_ENV=${env}. Set BASE_URL_STAGING (or BASE_URL) in .env.`);
  }

  return url;
}

export function validateEnvironment(options: { requirePassword?: boolean } = {}): void {
  const { requirePassword = true } = options;

  if (useMockApp()) {
    if (!process.env.APP_PASSWORD) {
      process.env.APP_PASSWORD = 'password';
    }
    return;
  }

  getBaseUrl();

  if (requirePassword && !process.env.APP_PASSWORD) {
    throw new Error('APP_PASSWORD is required. Copy .env.example to .env and set credentials.');
  }
}

export function getApiBaseUrl(): string {
  if (useMockApp()) {
    return getMockAppUrl();
  }

  return process.env.API_BASE_URL ?? 'https://jsonplaceholder.typicode.com';
}

export function getEnvironmentLabel(): string {
  return getTestEnvironment();
}
