import AxeBuilder from '@axe-core/playwright';
import { Page } from 'playwright';

export async function runAccessibilityScan(page: Page) {
  return new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
}

export async function assertNoCriticalViolations(page: Page): Promise<void> {
  const results = await runAccessibilityScan(page);
  const critical = results.violations.filter(
    (violation) => violation.impact === 'critical' || violation.impact === 'serious'
  );

  if (critical.length) {
    const summary = critical.map((v) => `${v.id}: ${v.description}`).join('\n');
    throw new Error(`Accessibility violations found:\n${summary}`);
  }
}
