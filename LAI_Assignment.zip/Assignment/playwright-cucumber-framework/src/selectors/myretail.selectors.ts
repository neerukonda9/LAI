// data-test selectors; class fallbacks for legacy demo markup — see docs/selector-strategy.md
export const MyRetailSelectors = {
  username: '[data-test="username"]',
  password: '[data-test="password"]',
  loginButton: '[data-test="login-button"]',
  errorMessage: '[data-test="error"]',
  productSort: '[data-test="product-sort-container"]',
  pageTitle: '.title',
  cartBadge: '.shopping_cart_badge',
  loginContainer: '#login-view',
  inventoryItem: '.inventory_item',
  inventoryItemName: '.inventory_item_name',
  inventoryList: '.inventory_list'
} as const;
