import { APIRequestContext } from 'playwright';
import { getApiBaseUrl } from '../support/env';
import { ApiUserPayload } from '../support/factories/user.factory';

export class ApiClient {
  constructor(private readonly request: APIRequestContext) {}

  async createUser(payload: ApiUserPayload) {
    return this.request.post(`${getApiBaseUrl()}/posts`, {
      data: { title: payload.name, body: payload.job, userId: payload.userId }
    });
  }

  async getPost(postId: number) {
    return this.request.get(`${getApiBaseUrl()}/posts/${postId}`);
  }
}
