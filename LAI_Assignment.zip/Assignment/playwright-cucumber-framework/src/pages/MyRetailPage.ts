import path from 'path';
import { mkdirSync } from 'fs';
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from './BasePage';
import { MyRetailSelectors } from '../selectors/myretail.selectors';
import { trackAddToCart, trackLoginSuccess } from '../support/analytics-helper';

export class MyRetailPage extends BasePage {
  private readonly usernameInput: Locator;
  private readonly passwordInput: Locator;
  private readonly loginButton: Locator;
  private readonly errorMessage: Locator;
  private readonly pageTitle: Locator;
  private readonly cartBadge: Locator;
  private readonly loginContainer: Locator;

  constructor(page: Page) {
    super(page);
    this.usernameInput = page.locator(MyRetailSelectors.username);
    this.passwordInput = page.locator(MyRetailSelectors.password);
    this.loginButton = page.locator(MyRetailSelectors.loginButton);
    this.errorMessage = page.locator(MyRetailSelectors.errorMessage);
    this.pageTitle = page.locator(MyRetailSelectors.pageTitle);
    this.cartBadge = page.locator(MyRetailSelectors.cartBadge);
    this.loginContainer = page.locator(MyRetailSelectors.loginContainer);
  }

  async open(baseUrl: string): Promise<void> {
    await this.navigateTo(baseUrl);
  }

  async login(username: string, password: string): Promise<void> {
    const appPassword = password === 'password' ? (process.env.APP_PASSWORD ?? password) : password;
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(appPassword);
    await this.loginButton.click();
    if (await this.isProductsPageVisible()) {
      await trackLoginSuccess(this.page, username);
    }
  }

  async getErrorMessage(): Promise<string> {
    return (await this.errorMessage.textContent()) ?? '';
  }

  async isProductsPageVisible(): Promise<boolean> {
    return this.pageTitle.isVisible();
  }

  async getPageTitleText(): Promise<string> {
    return (await this.pageTitle.textContent()) ?? '';
  }

  async addProductToCart(productName: string): Promise<void> {
    const productContainer = this.page.locator(MyRetailSelectors.inventoryItem, {
      has: this.page.locator(MyRetailSelectors.inventoryItemName, { hasText: productName })
    });
    await productContainer.locator('button', { hasText: 'Add to cart' }).click();
    await trackAddToCart(this.page, productName);
  }

  async getCartBadgeCount(): Promise<string> {
    return (await this.cartBadge.textContent()) ?? '';
  }

  async compareLoginVisualBaseline(): Promise<void> {
    const outputDir = path.join(process.cwd(), 'reports', 'screenshots');
    mkdirSync(outputDir, { recursive: true });
    await this.loginContainer.screenshot({
      path: path.join(outputDir, 'login-page-baseline.png')
    });
  }
}
