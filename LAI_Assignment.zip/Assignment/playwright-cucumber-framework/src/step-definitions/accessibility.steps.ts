import { Then } from '@cucumber/cucumber';
import { PlaywrightWorld } from '../support/world';
import { assertNoCriticalViolations } from '../support/accessibility-helper';

Then(
  'the login page should have no critical accessibility violations',
  async function (this: PlaywrightWorld) {
    await assertNoCriticalViolations(this.page);
  }
);

Then(
  'the inventory page should have no critical accessibility violations',
  async function (this: PlaywrightWorld) {
    await assertNoCriticalViolations(this.page);
  }
);

Then('the login page should match the visual baseline', async function (this: PlaywrightWorld) {
  await this.myRetailPage.compareLoginVisualBaseline();
});
