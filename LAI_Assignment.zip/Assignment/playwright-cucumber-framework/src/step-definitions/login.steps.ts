import { Given, When, Then, DataTable } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PlaywrightWorld } from '../support/world';
import { loginAsUser } from '../support/login-helper';
import { resolveUsername } from '../support/test-data';

Given('I navigate to the MyRetail application', async function (this: PlaywrightWorld) {
  await this.myRetailPage.open(this.baseUrl);
});

Given('I am logged in as {string}', async function (this: PlaywrightWorld, username: string) {
  await loginAsUser(this, resolveUsername(username));
});

When(
  'I login with username {string} and password {string}',
  async function (this: PlaywrightWorld, username: string, password: string) {
    await this.myRetailPage.login(resolveUsername(username), password);
  }
);

Then('I should see the products page', async function (this: PlaywrightWorld) {
  const isVisible = await this.myRetailPage.isProductsPageVisible();
  expect(isVisible).toBeTruthy();
});

Then(
  'the page title should contain {string}',
  async function (this: PlaywrightWorld, title: string) {
    const pageTitle = await this.myRetailPage.getPageTitleText();
    expect(pageTitle).toContain(title);
  }
);

Then(
  'I should see an error message {string}',
  async function (this: PlaywrightWorld, message: string) {
    const errorMessage = await this.myRetailPage.getErrorMessage();
    expect(errorMessage).toContain(message);
  }
);

When(
  'I attempt login with the following invalid credentials:',
  async function (this: PlaywrightWorld, table: DataTable) {
    for (const row of table.hashes()) {
      await this.myRetailPage.open(this.baseUrl);
      await this.myRetailPage.login(row['username'] ?? '', row['password'] ?? '');
      const errorMessage = await this.myRetailPage.getErrorMessage();
      expect(errorMessage).toContain(row['expected_error']);
    }
  }
);
