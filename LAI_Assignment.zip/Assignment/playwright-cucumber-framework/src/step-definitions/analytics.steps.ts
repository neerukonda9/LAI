import { Given, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PlaywrightWorld } from '../support/world';
import { hasAnalyticsEvent } from '../support/analytics-helper';

Given('analytics tracking is enabled', async function (this: PlaywrightWorld) {
  await this.myRetailPage.open(this.baseUrl);
});

Then(
  'an analytics event {string} should be recorded',
  async function (this: PlaywrightWorld, eventName: string) {
    const found = await hasAnalyticsEvent(this.page, eventName);
    expect(found).toBeTruthy();
  }
);

Then(
  'an analytics event {string} should include product {string}',
  async function (this: PlaywrightWorld, eventName: string, product: string) {
    const events = await this.page.evaluate(() => {
      const w = window as Window & { dataLayer?: Array<Record<string, unknown>> };
      return w.dataLayer ?? [];
    });
    const match = events.find(
      (event: Record<string, unknown>) => event.event === eventName && event.product === product
    );
    expect(match).toBeTruthy();
  }
);
