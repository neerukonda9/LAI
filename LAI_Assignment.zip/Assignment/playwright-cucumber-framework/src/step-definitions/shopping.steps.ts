import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PlaywrightWorld } from '../support/world';
import { getCartItems, getExpectedCartCount } from '../support/test-data';

When('I add cart items from test data', async function (this: PlaywrightWorld) {
  const products = getCartItems();
  for (const item of products) {
    await this.myRetailPage.addProductToCart(item.productName);
  }
});

Then(
  'the shopping cart badge should show {string} items',
  async function (this: PlaywrightWorld, count: string) {
    const badgeCount = await this.myRetailPage.getCartBadgeCount();
    expect(badgeCount).toBe(count);
  }
);

Then(
  'the shopping cart badge should match test data count',
  async function (this: PlaywrightWorld) {
    const badgeCount = await this.myRetailPage.getCartBadgeCount();
    expect(badgeCount).toBe(getExpectedCartCount());
  }
);
