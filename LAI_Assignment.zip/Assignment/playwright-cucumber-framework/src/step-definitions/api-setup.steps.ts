import { Given } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PlaywrightWorld } from '../support/world';
import { buildApiUser } from '../support/factories/user.factory';

Given('API test data is prepared via JSONPlaceholder', async function (this: PlaywrightWorld) {
  const payload = buildApiUser();
  const response = await this.apiClient.createUser(payload);
  expect(response.ok()).toBeTruthy();
  const body = await response.json();
  this.apiSetupPostId = body.id;
});
