# Playwright Cucumber Framework

TypeScript BDD tests with Playwright, Cucumber, and Page Object Model.

![Architecture](docs/architecture.png)

## Setup

```bash
npm install
cp .env.example .env
```

### Run without a real app (mock mode)

No `BASE_URL` or password needed. A local mock server serves MyRetail UI and JSONPlaceholder-shaped API responses.

#### Auto-start (recommended)

`test:mock` and `test:mock:smoke` **do not require you to start the mock server first**. They use `scripts/run-with-mock.js`, which:

1. Starts `mock-app/server.js` on `http://127.0.0.1:4173`
2. Waits for `GET /health` to respond
3. Runs tests with `USE_MOCK_APP=true` and password `password`
4. Stops the mock server when tests finish (pass or fail)

```bash
npm run test:mock:smoke   # auto-start mock → @smoke → auto-stop
npm run test:mock         # auto-start mock → full suite → auto-stop
```

#### Manual start (debugging)

Start the mock server yourself when you want to inspect the app in a browser, re-run tests without restarting the server, or use the regular test commands.

**Terminal 1 — keep running**

```bash
npm run mock:server
```

Open `http://127.0.0.1:4173` in a browser. Mock login: `standard_user` / `password`.

**Terminal 2 — run tests against the running mock**

Copy `.env.example` to `.env` and set:

```bash
USE_MOCK_APP=true
MOCK_APP_URL=http://127.0.0.1:4173
APP_PASSWORD=password
```

Then run any command that does **not** use `test:mock` (those would try to start a second server on the same port):

```bash
npm run test:smoke
npm run test:regression
npm test
```

To use a different port: `MOCK_APP_PORT=4174 npm run mock:server` and set `MOCK_APP_URL=http://127.0.0.1:4174` in `.env`.

Mock behaviour and user rules: `mock-app/public/app.js`.

### Real app credentials

When `USE_MOCK_APP` is false or unset:

| Variable                        | Notes                                             |
| ------------------------------- | ------------------------------------------------- |
| `TEST_ENV`                      | `dev`, `staging`, or `prod` (default: `staging`)  |
| `BASE_URL` / `BASE_URL_STAGING` | App URL for staging                               |
| `BASE_URL_DEV`, `BASE_URL_PROD` | Optional tier URLs                                |
| `APP_PASSWORD`                  | Login password (`password` in features maps here) |
| `API_BASE_URL`                  | JSONPlaceholder for `@api` tests                  |

Missing env vars fail at startup (`src/support/env.ts`).

Pre-commit: repo root `.husky/pre-commit` runs lint-staged on changed files in this folder.

## Commands

| Command                      | Purpose                                   |
| ---------------------------- | ----------------------------------------- |
| `npm test`                   | Full suite                                |
| `npm run test:mock:smoke`    | Auto-start mock, run `@smoke`, auto-stop (no manual server) |
| `npm run test:mock`          | Auto-start mock, full suite, auto-stop                      |
| `npm run mock:server`        | Mock only — use for debugging (see Setup above)             |
| `npm run test:smoke`         | `@smoke` only                               |
| `npm run test:regression`    | `@regression`                             |
| `npm run test:parallel`      | One process per feature file              |
| `npm run test:report`        | Tests + Cucumber HTML + metrics           |
| `npm run test:allure`        | Tests + Allure report + metrics           |
| `npm run test:notify`        | Tests + report + Slack                    |
| `npm run test:browserstack`  | BrowserStack (needs creds in `.env`)      |
| `npm run test:report:zephyr` | Tests + report + JIRA upload              |
| `npm run validate`           | typecheck, ESLint, gherkin-lint, Prettier |
| `npm run metrics`            | Write `reports/test-metrics.json`         |
| `npm run audit:check`        | npm audit (high severity)                 |

## Feature files

| File                    | Tags                        | Notes                                    |
| ----------------------- | --------------------------- | ---------------------------------------- |
| `login.feature`         | `@feature-login`            | Explicit login steps for pass/fail paths |
| `shopping.feature`      | `@feature-shopping`         | Composite login + cart                   |
| `inventory-ui.feature`  | `@ui`, `@api-setup`         | API seed, then UI                        |
| `accessibility.feature` | `@accessibility`, `@visual` | axe + screenshot baseline                |
| `analytics.feature`     | `@analytics`                | `dataLayer` events                       |

## Login steps

| Use case                  | Step                                                       |
| ------------------------- | ---------------------------------------------------------- |
| Login test (pass or fail) | `When I login with username "..." and password "password"` |
| Already logged in         | `Given I am logged in as "standard_user"`                  |
| Invalid credentials       | `When I attempt login with the following invalid credentials:` + data table |

## Tags

| Tag              | CI usage                  |
| ---------------- | ------------------------- |
| `@smoke`         | PR pipeline               |
| `@regression`    | Nightly / release         |
| `@api`           | API only (no UI)          |
| `@ui`            | UI only                   |
| `@api-setup`     | API precondition, then UI |
| `@accessibility` | axe scan                  |
| `@analytics`     | dataLayer checks          |
| `@visual`        | Screenshot baseline       |
| `@feature-*`     | Domain grouping           |

## Test data

| Path                                    | Contents                                         |
| --------------------------------------- | ------------------------------------------------ |
| `testdata/users.json`                   | Valid user, locked user, invalid credential rows |
| `testdata/products.json`                | Cart items, sort expectations                    |
| `src/support/factories/user.factory.ts` | Unique API user payloads                         |

Load helpers: `src/support/test-data.ts`.

## Selectors

All locators live in `src/selectors/myretail.selectors.ts`. Page objects import from there — no raw selectors in steps. See `docs/selector-strategy.md`.

## API vs UI

- **`@api`**: JSONPlaceholder via `ApiClient` — no browser login.
- **`@ui`**: Browser only.
- **`@api-setup`**: `Given API test data is prepared via JSONPlaceholder` then UI steps.

## Accessibility and analytics

- **Accessibility**: `@axe-core/playwright` — critical/serious violations fail the run.
- **Analytics**: `dataLayer` stub in `src/support/analytics-helper.ts`; login and add-to-cart push events.
- **Visual**: screenshot saved to `reports/screenshots/` on `@visual` scenarios.

## Reports

| Output        | Path                                               |
| ------------- | -------------------------------------------------- |
| Cucumber HTML | `reports/html/index.html`                          |
| Cucumber JSON | `reports/cucumber-report.json`                     |
| Allure        | `reports/allure-report/`                           |
| Metrics       | `reports/test-metrics.json`                        |
| Slack         | `npm run notify:slack` (needs `SLACK_WEBHOOK_URL`) |

Allure includes `TEST_ENV`, Node version, and OS in metadata.

## Code quality

- `eslint.config.cjs` — TypeScript lint
- `.gherkin-lintrc` — feature file rules
- `.prettierrc.json` — formatting
- `.nvmrc` — Node 20

```bash
npm run validate
```

## CI/CD

```
PR      → validate + test:smoke
Nightly → test:parallel + allure:report + metrics + Slack
Release → test:browserstack + upload:zephyr (tag: playwright-v*)
```

Workflows (repo root):

| Workflow | File                                                                                      |
| -------- | ----------------------------------------------------------------------------------------- |
| PR       | [`.github/workflows/playwright-pr.yml`](../.github/workflows/playwright-pr.yml)           |
| Nightly  | [`.github/workflows/playwright-nightly.yml`](../.github/workflows/playwright-nightly.yml) |
| Release  | [`.github/workflows/playwright-release.yml`](../.github/workflows/playwright-release.yml) |
| Security | [`.github/workflows/security-scan.yml`](../.github/workflows/security-scan.yml)           |

GitHub secrets: `BASE_URL`, `APP_PASSWORD`, `SLACK_WEBHOOK_URL`, `BROWSERSTACK_*`, `ZEPHYR_API_TOKEN`. Variables: `ZEPHYR_PROJECT_KEY`, `ZEPHYR_TEST_CYCLE_KEY`.

Dependabot: [`.github/dependabot.yml`](../.github/dependabot.yml). Secret scanning: `.gitleaks.toml`.

## JIRA / BrowserStack

```bash
npm run test:report:zephyr   # needs ZEPHYR_* in .env
npm run test:browserstack    # needs BROWSERSTACK_* in .env
```

Map scenarios in `config/zephyr-map.json`.

## Project layout

```
features/
testdata/
src/pages/
src/selectors/
src/step-definitions/
src/support/
scripts/
mock-app/
config/
docs/
```

Interview prep guide: [`docs/INTERVIEW-GUIDE.md`](../docs/INTERVIEW-GUIDE.md)

## Technology stack

- **Language / runtime**: TypeScript 5, Node.js 20
- **Test runner**: Playwright 1.x — Chromium, API request context, screenshots
- **BDD**: `@cucumber/cucumber` — Gherkin features, hooks, tags
- **Page objects**: custom POM under `src/pages/` + `src/selectors/`
- **Mock app**: Node `http` server in `mock-app/` for offline/CI runs
- **Reporting**: `multiple-cucumber-html-reporter`, Allure (`allure-cucumberjs`)
- **Accessibility**: `@axe-core/playwright`
- **Analytics**: custom `dataLayer` helper
- **Visual**: Playwright `toHaveScreenshot` — baselines under `src/pages/*-snapshots/`
- **Lint / format**: ESLint 9, Prettier, gherkin-lint
- **Git hooks**: Husky + lint-staged (repo root)
- **CI/CD**: GitHub Actions
- **Security**: Gitleaks, Dependabot, `npm audit`
- **Env loading**: `cross-env`, `scripts/load-env.js`
- **Optional**: BrowserStack, Zephyr Scale, Slack webhook
