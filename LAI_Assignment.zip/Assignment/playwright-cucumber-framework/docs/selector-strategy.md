# Selectors

Use `[data-test="..."]` attributes. Define them once in `selectors/myretail.selectors.ts` and import in page objects.

Do not put selectors in step definitions or feature files.

If the app is missing a `data-test` attribute, add it in the application code rather than using CSS classes or XPath in tests.
