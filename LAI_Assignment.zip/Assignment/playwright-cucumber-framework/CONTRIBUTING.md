# Contributing

## Where to add code

| Type           | Location                                                    |
| -------------- | ----------------------------------------------------------- |
| Feature        | `features/*.feature`                                        |
| Steps          | `src/step-definitions/*.steps.ts`                           |
| Page object    | `src/pages/`                                                |
| Selectors      | `src/selectors/`                                            |
| Test data      | `testdata/*.json`                                           |
| Factories      | `src/support/factories/`                                    |
| API-only tests | Tag with `@api` — no UI steps                               |
| UI tests       | Tag with `@ui`; use `@api-setup` if API precondition needed |

## Login patterns

- **Negative login tests**: explicit `When I login with username ...`
- **Authenticated flows**: `Given I am logged in as "standard_user"`

## Tags

| Tag              | Use                               |
| ---------------- | --------------------------------- |
| `@smoke`         | PR pipeline                       |
| `@regression`    | Nightly                           |
| `@api`           | API-only (no browser UI)          |
| `@ui`            | UI-only                           |
| `@api-setup`     | UI scenario with API precondition |
| `@accessibility` | axe scans                         |
| `@analytics`     | dataLayer events                  |
| `@visual`        | Screenshot comparison             |

## Environment

Set `TEST_ENV=dev|staging|prod` and matching `BASE_URL_*` in `.env`. Tests fail fast if env is invalid.

## Before opening a PR

```bash
npm run validate
npm run test:smoke
```
