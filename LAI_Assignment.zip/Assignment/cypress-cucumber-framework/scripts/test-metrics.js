const fs = require('fs');
const path = require('path');

require('./load-env');

const reportPath = path.join(__dirname, '../reports/cucumber-report.json');
const outputPath = path.join(__dirname, '../reports/test-metrics.json');

function buildMetrics(report) {
  const scenarios = [];
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  let totalDurationNs = 0;

  for (const feature of report) {
    for (const element of feature.elements || []) {
      if (element.type !== 'scenario') {
        continue;
      }

      const steps = element.steps || [];
      const durationNs = steps.reduce((sum, step) => sum + (step.result?.duration ?? 0), 0);
      totalDurationNs += durationNs;
      const hasFailure = steps.some((step) => step.result?.status === 'failed');
      const hasSkipped = steps.some((step) => step.result?.status === 'skipped');
      const status = hasFailure ? 'failed' : hasSkipped ? 'skipped' : 'passed';

      if (status === 'failed') failed += 1;
      else if (status === 'skipped') skipped += 1;
      else passed += 1;

      scenarios.push({
        feature: feature.name,
        scenario: element.name,
        status,
        durationMs: Math.round(durationNs / 1_000_000)
      });
    }
  }

  return {
    generatedAt: new Date().toISOString(),
    environment: process.env.TEST_ENV ?? 'staging',
    summary: {
      total: passed + failed + skipped,
      passed,
      failed,
      skipped,
      totalDurationMs: Math.round(totalDurationNs / 1_000_000)
    },
    scenarios: scenarios.sort((a, b) => b.durationMs - a.durationMs)
  };
}

if (!fs.existsSync(reportPath)) {
  console.error(`Report not found: ${reportPath}`);
  process.exit(1);
}

const report = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
const metrics = buildMetrics(report);
fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(metrics, null, 2));

console.log(JSON.stringify(metrics.summary, null, 2));
