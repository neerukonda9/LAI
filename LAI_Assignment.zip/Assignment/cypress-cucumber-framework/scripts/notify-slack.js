const fs = require('fs');
const path = require('path');

require('./load-env');

const reportPath = path.join(__dirname, '../reports/cucumber-report.json');
const webhookUrl = process.env.SLACK_WEBHOOK_URL;
const projectName = process.env.SLACK_PROJECT_NAME || 'Cypress Cucumber';

function summarizeReport(report) {
  let passed = 0;
  let failed = 0;
  let skipped = 0;
  const failures = [];

  for (const feature of report) {
    for (const element of feature.elements || []) {
      if (element.type !== 'scenario') {
        continue;
      }

      const steps = element.steps || [];
      const hasFailure = steps.some((step) => step.result?.status === 'failed');
      const hasSkipped = steps.some((step) => step.result?.status === 'skipped');

      if (hasFailure) {
        failed += 1;
        failures.push(`${feature.name} → ${element.name}`);
      } else if (hasSkipped) {
        skipped += 1;
      } else {
        passed += 1;
      }
    }
  }

  return { passed, failed, skipped, failures };
}

async function notifySlack() {
  if (!webhookUrl) {
    console.warn('SLACK_WEBHOOK_URL not set — skipping Slack notification.');
    return;
  }

  if (!fs.existsSync(reportPath)) {
    throw new Error(`Report not found at ${reportPath}. Run tests first.`);
  }

  const report = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
  const { passed, failed, skipped, failures } = summarizeReport(report);
  const total = passed + failed + skipped;
  const statusEmoji = failed > 0 ? ':x:' : ':white_check_mark:';

  let durationLine = '';
  const metricsPath = path.join(__dirname, '../reports/test-metrics.json');
  if (fs.existsSync(metricsPath)) {
    const metrics = JSON.parse(fs.readFileSync(metricsPath, 'utf8'));
    durationLine = `*Duration:* ${metrics.summary.totalDurationMs}ms | *Env:* ${metrics.environment}`;
  }

  const payload = {
    blocks: [
      {
        type: 'header',
        text: { type: 'plain_text', text: `${statusEmoji} ${projectName} test run` }
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Total:* ${total}` },
          { type: 'mrkdwn', text: `*Passed:* ${passed}` },
          { type: 'mrkdwn', text: `*Failed:* ${failed}` },
          { type: 'mrkdwn', text: `*Skipped:* ${skipped}` }
        ]
      }
    ]
  };

  if (durationLine) {
    payload.blocks.push({
      type: 'section',
      text: { type: 'mrkdwn', text: durationLine }
    });
  }

  if (failures.length) {
    payload.blocks.push({
      type: 'section',
      text: {
        type: 'mrkdwn',
        text: `*Failures:*\n${failures.map((item) => `• ${item}`).join('\n')}`
      }
    });
  }

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Slack notification failed (${response.status}): ${text}`);
  }

  console.log('Slack notification sent.');
}

notifySlack().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
