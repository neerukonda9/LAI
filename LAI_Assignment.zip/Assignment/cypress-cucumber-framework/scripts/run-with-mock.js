const { spawn, execSync } = require('child_process');
const http = require('http');
const path = require('path');

const PORT = process.env.MOCK_APP_PORT || '4173';
const MOCK_URL = process.env.MOCK_APP_URL || `http://127.0.0.1:${PORT}`;
const testScript = process.argv[2] || 'test:smoke';
const serverPath = path.join(__dirname, '../mock-app/server.js');

function freePort(port) {
  if (process.platform !== 'win32') {
    return;
  }

  try {
    execSync(
      `powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort ${port} -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"`,
      { stdio: 'ignore' }
    );
  } catch {
    // Port already free.
  }
}

freePort(PORT);

const server = spawn(process.execPath, [serverPath], {
  stdio: 'inherit',
  env: {
    ...process.env,
    MOCK_APP_PORT: PORT,
    APP_PASSWORD: process.env.APP_PASSWORD || 'password',
    MOCK_APP_PASSWORD: process.env.MOCK_APP_PASSWORD || 'password'
  }
});

let testsStarted = false;

function waitForHealth(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;

  return new Promise((resolve, reject) => {
    const poll = () => {
      const request = http.get(`${MOCK_URL}/health`, (response) => {
        response.resume();
        if (response.statusCode === 200) {
          resolve();
          return;
        }
        retry();
      });

      request.on('error', retry);

      function retry() {
        if (Date.now() > deadline) {
          reject(new Error(`Mock server not ready at ${MOCK_URL}`));
          return;
        }
        setTimeout(poll, 250);
      }
    };

    poll();
  });
}

function shutdown(exitCode = 0) {
  server.kill();
  process.exit(exitCode);
}

server.on('error', (error) => {
  console.error(error);
  shutdown(1);
});

server.on('exit', (code) => {
  if (!testsStarted && code !== 0 && code !== null) {
    console.error(`Mock server exited before tests started (code ${code})`);
    shutdown(1);
  }
});

waitForHealth()
  .then(() => {
    testsStarted = true;
    const testEnv = {
      ...process.env,
      USE_MOCK_APP: 'true',
      MOCK_APP_URL: MOCK_URL,
      CYPRESS_APP_PASSWORD: process.env.CYPRESS_APP_PASSWORD || 'password',
      CYPRESS_BASE_URL: MOCK_URL,
      CYPRESS_BASE_URL_STAGING: MOCK_URL,
      API_BASE_URL: MOCK_URL
    };

    const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    const testRun = spawn(npmCmd, ['run', testScript], {
      stdio: 'inherit',
      env: testEnv,
      shell: process.platform === 'win32'
    });

    testRun.on('close', (code) => shutdown(code ?? 1));
  })
  .catch((error) => {
    console.error(error.message);
    shutdown(1);
  });

process.on('SIGINT', () => shutdown(130));
process.on('SIGTERM', () => shutdown(143));
