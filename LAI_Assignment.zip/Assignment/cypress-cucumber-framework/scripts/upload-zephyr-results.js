const fs = require('fs');
const path = require('path');

require('./load-env');

const jsonPath = path.join(__dirname, '../reports/cucumber-report.json');
const mapPath = path.join(__dirname, '../config/zephyr-map.json');

const {
  ZEPHYR_API_TOKEN,
  ZEPHYR_BASE_URL = 'https://api.zephyrscale.smartbear.com/v2',
  ZEPHYR_PROJECT_KEY,
  ZEPHYR_TEST_CYCLE_KEY,
  ZEPHYR_VERSION_ID
} = process.env;

function loadReport() {
  if (!fs.existsSync(jsonPath)) {
    throw new Error(`Cucumber JSON not found at ${jsonPath}. Run tests first.`);
  }
  const raw = fs.readFileSync(jsonPath, 'utf8');
  return JSON.parse(raw);
}

function loadMap() {
  if (!fs.existsSync(mapPath)) {
    return {};
  }
  return JSON.parse(fs.readFileSync(mapPath, 'utf8'));
}

function mapStatus(status) {
  if (status === 'passed') return 'Pass';
  if (status === 'failed') return 'Fail';
  if (status === 'skipped') return 'Not Executed';
  return 'Blocked';
}

function getTestCaseKey(scenario, map) {
  const tagKey = (scenario.tags || [])
    .map((t) => t.name.replace('@', ''))
    .find((name) => /^[A-Z]+-T\d+$/i.test(name));

  if (tagKey) {
    return tagKey.toUpperCase();
  }

  return map[scenario.name] || null;
}

function buildExecutions(report, map) {
  const executions = [];

  for (const feature of report) {
    for (const element of feature.elements || []) {
      if (element.type !== 'scenario') {
        continue;
      }

      const testCaseKey = getTestCaseKey(element, map);
      if (!testCaseKey) {
        console.warn(`No Zephyr key for scenario: ${element.name}`);
        continue;
      }

      const stepResults = (element.steps || []).map((step) => ({
        status: mapStatus(step.result?.status),
        actualResult: step.result?.error_message || step.name
      }));

      const failed = stepResults.some((s) => s.status === 'Fail');
      const status = failed ? 'Fail' : 'Pass';

      executions.push({
        testCaseKey,
        status,
        comment: `Automated run: ${feature.name} / ${element.name}`,
        executionTime: element.steps?.reduce((sum, step) => sum + (step.result?.duration || 0), 0),
        steps: stepResults
      });
    }
  }

  return executions;
}

async function uploadToZephyr() {
  if (!ZEPHYR_API_TOKEN || !ZEPHYR_PROJECT_KEY) {
    throw new Error('Set ZEPHYR_API_TOKEN and ZEPHYR_PROJECT_KEY in .env');
  }

  const report = loadReport();
  const map = loadMap();
  const executions = buildExecutions(report, map);

  if (!executions.length) {
    throw new Error(
      'No executions to upload. Add @PROJECT-T1 tags or update config/zephyr-map.json'
    );
  }

  const body = {
    projectKey: ZEPHYR_PROJECT_KEY,
    testCycleKey: ZEPHYR_TEST_CYCLE_KEY,
    version: ZEPHYR_VERSION_ID ? { id: Number(ZEPHYR_VERSION_ID) } : undefined,
    executions
  };

  const response = await fetch(`${ZEPHYR_BASE_URL}/automation/executions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${ZEPHYR_API_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Zephyr upload failed (${response.status}): ${text}`);
  }

  const result = await response.json();
  console.log(`Uploaded ${executions.length} result(s) to Zephyr Scale.`);
  console.log(JSON.stringify(result, null, 2));
}

uploadToZephyr().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
