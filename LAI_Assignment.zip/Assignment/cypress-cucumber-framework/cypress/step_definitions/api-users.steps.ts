import { When, Then } from '@badeball/cypress-cucumber-preprocessor';
import { buildApiUser } from '../support/factories/user.factory';
import { UserApiPage } from '../pages/UserApiPage';

When('I create a user from test data factory', () => {
  const payload = buildApiUser();
  const userApiPage = new UserApiPage(Cypress.env('apiBaseUrl'));
  userApiPage.createUser(payload.name, payload.job).then((response) => {
    cy.setLastApiResponse(response);
    Cypress.env('lastFactoryUserName', payload.name);
  });
});

When('I create a user from test data', () => {
  cy.fixture('api-users').then((data) => {
    const userApiPage = new UserApiPage(Cypress.env('apiBaseUrl'));
    userApiPage.createUser(data.createUser.name, data.createUser.job).then((response) => {
      cy.setLastApiResponse(response);
    });
  });
});

When('I update a user from test data', () => {
  cy.fixture('api-users').then((data) => {
    const userApiPage = new UserApiPage(Cypress.env('apiBaseUrl'));
    userApiPage
      .updateUser(data.updateUser.userId, data.updateUser.name, data.updateUser.job)
      .then((response) => {
        cy.setLastApiResponse(response);
      });
  });
});

Then('the API response status should be {int}', (statusCode: number) => {
  cy.getLastApiResponse().its('status').should('eq', statusCode);
});

Then('the API response body should match the create user test data', () => {
  cy.fixture('api-users').then((data) => {
    cy.getLastApiResponse().its('body.title').should('eq', data.createUser.name);
    cy.getLastApiResponse().its('body.body').should('eq', data.createUser.job);
    cy.getLastApiResponse().its('body.id').should('be.a', 'number');
  });
});

Then('the API response body should match the factory user name', () => {
  cy.getLastApiResponse().its('body.title').should('eq', Cypress.env('lastFactoryUserName'));
});

Then('the API response body should match the update user test data', () => {
  cy.fixture('api-users').then((data) => {
    cy.getLastApiResponse().its('body.title').should('eq', data.updateUser.name);
    cy.getLastApiResponse().its('body.body').should('eq', data.updateUser.job);
    cy.getLastApiResponse().its('body.id').should('eq', Number(data.updateUser.userId));
  });
});
