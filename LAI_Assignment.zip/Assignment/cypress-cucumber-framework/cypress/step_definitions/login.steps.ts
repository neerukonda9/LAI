import { Given, When, Then, DataTable } from '@badeball/cypress-cucumber-preprocessor';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';
import { loginAsUser } from '../support/login-helper';
import { resolveUsername } from '../support/test-data';

const loginPage = new LoginPage();
const inventoryPage = new InventoryPage();

Given('I open the MyRetail login page', () => {
  loginPage.open();
});

Given('I am logged in as {string}', (username: string) => {
  cy.fixture('users').then((users) => {
    loginAsUser(resolveUsername(users, username));
  });
});

When(
  'I login with username {string} and password {string}',
  (username: string, password: string) => {
    cy.fixture('users').then((users) => {
      loginPage.login(resolveUsername(users, username), password);
    });
  }
);

Then('I should land on the inventory page', () => {
  inventoryPage.assertPageLoaded();
});

Then('the inventory page title should be {string}', (title: string) => {
  inventoryPage.getPageTitle().should('eq', title);
});

Then('I should see a login error containing {string}', (message: string) => {
  loginPage.getErrorMessage().should('contain', message);
});

When('I attempt login with the following invalid credentials:', (table: DataTable) => {
  table.hashes().forEach((row) => {
    cy.then(() => {
      loginPage.open();
      loginPage.login(row['username'] ?? '', row['password'] ?? '');
      loginPage.getErrorMessage().should('contain', row['expected_error']);
    });
  });
});
