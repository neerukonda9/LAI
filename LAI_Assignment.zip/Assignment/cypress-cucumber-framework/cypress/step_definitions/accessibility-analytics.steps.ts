import { Given, Then } from '@badeball/cypress-cucumber-preprocessor';
import { buildApiUser } from '../support/factories/user.factory';
import { getApiBaseUrl } from '../support/env';
import {
  enableAnalyticsTracking,
  assertAnalyticsEvent,
  assertAnalyticsEventWithProduct,
  injectAccessibilityContext,
  checkCriticalA11yViolations,
  captureLoginVisualSnapshot
} from '../support/analytics-helper';
import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';

const loginPage = new LoginPage();
const inventoryPage = new InventoryPage();

Given('API test data is prepared via JSONPlaceholder', () => {
  const payload = buildApiUser();
  cy.request('POST', `${getApiBaseUrl()}/posts`, {
    title: payload.name,
    body: payload.job,
    userId: payload.userId
  }).then((response) => {
    expect(response.status).to.eq(201);
    Cypress.env('apiSetupPostId', response.body.id);
  });
});

Given('analytics tracking is enabled', () => {
  loginPage.open();
  enableAnalyticsTracking();
});

Then('an analytics event {string} should be recorded', (eventName: string) => {
  assertAnalyticsEvent(eventName);
});

Then(
  'an analytics event {string} should include product {string}',
  (eventName: string, product: string) => {
    assertAnalyticsEventWithProduct(eventName, product);
  }
);

Then('the login page should have no critical accessibility violations', () => {
  injectAccessibilityContext();
  checkCriticalA11yViolations();
});

Then('the inventory page should have no critical accessibility violations', () => {
  inventoryPage.assertPageLoaded();
  injectAccessibilityContext();
  checkCriticalA11yViolations();
});

Then('the login page visual snapshot should be captured', () => {
  captureLoginVisualSnapshot('login-page-baseline');
});
