import { When, Then } from '@badeball/cypress-cucumber-preprocessor';
import { InventoryPage } from '../pages/InventoryPage';

const inventoryPage = new InventoryPage();

When('I add cart items from test data', () => {
  cy.fixture('products').then((products) => {
    products.cartItems.forEach((item: { productName: string }) => {
      inventoryPage.addProductToCart(item.productName);
    });
  });
});

When('I sort products by {string}', (sortOption: string) => {
  inventoryPage.sortBy(sortOption);
});

Then('the first product name should be {string}', (productName: string) => {
  inventoryPage.getFirstProductName().should('contain', productName);
});

Then('the first product price should be {string}', (price: string) => {
  inventoryPage.getFirstProductPrice().should('eq', price);
});
