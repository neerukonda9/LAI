const report = require('multiple-cucumber-html-reporter');
const path = require('path');
const fs = require('fs');

const jsonReportPath = path.join(__dirname, '../../reports/cucumber-report.json');

if (!fs.existsSync(jsonReportPath)) {
  console.error('No JSON report found. Run npm test first.');
  process.exit(1);
}

report.generate({
  jsonDir: path.join(__dirname, '../../reports'),
  reportPath: path.join(__dirname, '../../reports/html'),
  metadata: {
    browser: { name: 'chrome', version: 'latest' },
    platform: { name: process.platform, version: process.version }
  },
  displayDuration: true,
  openReportInBrowser: false
});
