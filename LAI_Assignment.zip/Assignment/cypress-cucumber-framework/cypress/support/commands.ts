let lastApiResponse: Cypress.Response<unknown> | undefined;

Cypress.Commands.add('getLastApiResponse', () => {
  if (!lastApiResponse) {
    throw new Error('API response should be set before assertion');
  }
  return cy.wrap(lastApiResponse);
});
Cypress.Commands.add('setLastApiResponse', (response: Cypress.Response<unknown>) => {
  lastApiResponse = response;
});

export { lastApiResponse };
