export type ApiUserPayload = {
  name: string;
  job: string;
  userId: number;
};

export function buildApiUser(overrides: Partial<ApiUserPayload> = {}): ApiUserPayload {
  const suffix = Date.now();
  return {
    name: `Auto User ${suffix}`,
    job: 'QA Engineer',
    userId: 1,
    ...overrides
  };
}

export function buildUniqueEmail(prefix = 'automation'): string {
  return `${prefix}.${Date.now()}@myretail.test`;
}
