export type TestEnvironment = 'dev' | 'staging' | 'prod';

const DEFAULT_MOCK_URL = 'http://127.0.0.1:4173';

const ENV_URL_MAP: Record<TestEnvironment, string | undefined> = {
  dev: Cypress.env('baseUrlDev') as string | undefined,
  staging: (Cypress.env('baseUrlStaging') ?? Cypress.env('baseUrl')) as string | undefined,
  prod: Cypress.env('baseUrlProd') as string | undefined
};

export function useMockApp(): boolean {
  const flag = Cypress.env('useMockApp');
  return flag === true || flag === 'true';
}

export function getMockAppUrl(): string {
  return (Cypress.env('mockAppUrl') as string) ?? DEFAULT_MOCK_URL;
}

export function getTestEnvironment(): TestEnvironment {
  const env = (Cypress.env('testEnv') ?? 'staging') as TestEnvironment;
  if (!['dev', 'staging', 'prod'].includes(env)) {
    throw new Error(`Invalid testEnv "${env}". Use dev, staging, or prod.`);
  }
  return env;
}

export function getBaseUrl(): string {
  if (useMockApp()) {
    return getMockAppUrl();
  }

  const env = getTestEnvironment();
  const url = ENV_URL_MAP[env];

  if (!url) {
    throw new Error(
      `Missing URL for testEnv=${env}. Set CYPRESS_BASE_URL_STAGING (or CYPRESS_BASE_URL) in .env.`
    );
  }

  return url;
}

export function validateEnvironment(options: { requirePassword?: boolean } = {}): void {
  const { requirePassword = true } = options;

  if (useMockApp()) {
    return;
  }

  getBaseUrl();

  if (requirePassword && !Cypress.env('appPassword')) {
    throw new Error(
      'CYPRESS_APP_PASSWORD is required. Copy .env.example to .env and set credentials.'
    );
  }
}

export function getApiBaseUrl(): string {
  if (useMockApp()) {
    return getMockAppUrl();
  }

  return (Cypress.env('apiBaseUrl') as string) ?? 'https://jsonplaceholder.typicode.com';
}
