import { LoginPage } from '../pages/LoginPage';
import { MyRetailSelectors } from '../selectors/myretail.selectors';

export function enableAnalyticsTracking(): void {
  cy.window().then((win) => {
    const w = win as Window & { dataLayer?: Array<Record<string, unknown>> };
    w.dataLayer = w.dataLayer ?? [];
  });
}

export function trackLoginSuccess(username: string): void {
  cy.window().then((win) => {
    const w = win as Window & { dataLayer?: Array<Record<string, unknown>> };
    w.dataLayer = w.dataLayer ?? [];
    w.dataLayer.push({ event: 'login_success', user: username, source: 'myretail' });
  });
}

export function trackAddToCart(productName: string): void {
  cy.window().then((win) => {
    const w = win as Window & { dataLayer?: Array<Record<string, unknown>> };
    w.dataLayer = w.dataLayer ?? [];
    w.dataLayer.push({ event: 'add_to_cart', product: productName, source: 'myretail' });
  });
}

export function assertAnalyticsEvent(eventName: string): void {
  cy.window().should((win) => {
    const w = win as Window & { dataLayer?: Array<Record<string, unknown>> };
    const events = w.dataLayer ?? [];
    const found = events.some((event) => event.event === eventName);
    expect(found, `Expected analytics event "${eventName}"`).to.eq(true);
  });
}

export function assertAnalyticsEventWithProduct(eventName: string, product: string): void {
  cy.window().should((win) => {
    const w = win as Window & { dataLayer?: Array<Record<string, unknown>> };
    const events = w.dataLayer ?? [];
    const found = events.some((event) => event.event === eventName && event.product === product);
    expect(found, `Expected event "${eventName}" with product "${product}"`).to.eq(true);
  });
}

export function injectAccessibilityContext(): void {
  cy.injectAxe();
}

export function checkCriticalA11yViolations(context?: string): void {
  cy.checkA11y(context ?? undefined, {
    includedImpacts: ['critical', 'serious']
  });
}

export function captureLoginVisualSnapshot(name: string): void {
  cy.get(MyRetailSelectors.loginContainer).should('be.visible');
  cy.screenshot(name, { capture: 'viewport' });
}

export { LoginPage };
