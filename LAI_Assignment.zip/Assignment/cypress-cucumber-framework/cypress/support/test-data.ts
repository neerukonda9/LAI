export type UserRecord = {
  username: string;
  password: string;
  errorMessage?: string;
};

export function getValidUser(): Cypress.Chainable<UserRecord> {
  return cy.fixture('users').then((users) => users.validUser as UserRecord);
}

export function getLockedOutUser(): Cypress.Chainable<UserRecord> {
  return cy.fixture('users').then((users) => users.lockedOutUser as UserRecord);
}

export function getInvalidCredentials(): Cypress.Chainable<
  Array<UserRecord & { expectedError: string }>
> {
  return cy.fixture('users').then((users) => users.invalidCredentials);
}

export function getCartItems(): Cypress.Chainable<Array<{ productName: string }>> {
  return cy.fixture('products').then((products) => products.cartItems);
}

export function getProductsPageTitle(): Cypress.Chainable<string> {
  return cy.fixture('products').then((products) => products.pageTitle as string);
}

export function resolveUsername(users: Record<string, UserRecord>, usernameOrKey: string): string {
  return users[usernameOrKey]?.username ?? usernameOrKey;
}
