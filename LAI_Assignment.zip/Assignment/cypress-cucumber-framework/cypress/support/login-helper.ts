import { LoginPage } from '../pages/LoginPage';
import { InventoryPage } from '../pages/InventoryPage';

const loginPage = new LoginPage();
const inventoryPage = new InventoryPage();

export function loginAsUser(username: string, password = 'password'): void {
  loginPage.open();
  loginPage.login(username, password);
  inventoryPage.assertPageLoaded();
}
