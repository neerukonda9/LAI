import './commands';
import '@shelex/cypress-allure-plugin';
import 'cypress-axe';
import { validateEnvironment, getBaseUrl } from './env';

before(() => {
  validateEnvironment();
});

beforeEach(() => {
  Cypress.config('baseUrl', getBaseUrl());
});

Cypress.on('uncaught:exception', () => false);

/* eslint-disable @typescript-eslint/no-namespace */
declare global {
  namespace Cypress {
    interface Chainable {
      getLastApiResponse(): Chainable<Cypress.Response<unknown>>;
      setLastApiResponse(response: Cypress.Response<unknown>): Chainable<void>;
    }
  }
}
/* eslint-enable @typescript-eslint/no-namespace */

export {};
