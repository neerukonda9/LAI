export class BasePage {
  protected visit(path: string): void {
    cy.visit(path);
  }
}
