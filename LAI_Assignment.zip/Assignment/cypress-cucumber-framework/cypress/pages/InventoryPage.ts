import { MyRetailSelectors } from '../selectors/myretail.selectors';
import { trackAddToCart } from '../support/analytics-helper';

export class InventoryPage {
  assertPageLoaded(): void {
    cy.url().should('include', '/inventory.html');
    cy.get(MyRetailSelectors.inventoryList).should('be.visible');
  }

  getPageTitle(): Cypress.Chainable<string> {
    return cy.get(MyRetailSelectors.pageTitle).invoke('text');
  }

  sortBy(option: string): void {
    cy.get(MyRetailSelectors.productSort).select(option);
  }

  getFirstProductName(): Cypress.Chainable<string> {
    return cy.get(MyRetailSelectors.inventoryItemName).first().invoke('text');
  }

  getFirstProductPrice(): Cypress.Chainable<string> {
    return cy.get('.inventory_item_price').first().invoke('text');
  }

  addProductToCart(productName: string): void {
    cy.contains(MyRetailSelectors.inventoryItemName, productName)
      .parents(MyRetailSelectors.inventoryItem)
      .find('button')
      .contains('Add to cart')
      .click();
    trackAddToCart(productName);
  }
}
