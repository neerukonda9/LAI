export class UserApiPage {
  private readonly baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  createUser(name: string, job: string): Cypress.Chainable<Cypress.Response<unknown>> {
    return cy.request({
      method: 'POST',
      url: `${this.baseUrl}/posts`,
      body: { title: name, body: job, userId: 1 },
      failOnStatusCode: false
    });
  }

  updateUser(
    userId: string,
    name: string,
    job: string
  ): Cypress.Chainable<Cypress.Response<unknown>> {
    return cy.request({
      method: 'PUT',
      url: `${this.baseUrl}/posts/${userId}`,
      body: { id: Number(userId), title: name, body: job, userId: 1 },
      failOnStatusCode: false
    });
  }
}
