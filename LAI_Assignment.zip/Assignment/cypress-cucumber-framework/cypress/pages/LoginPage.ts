import { MyRetailSelectors } from '../selectors/myretail.selectors';

export class LoginPage {
  open(): void {
    cy.visit('/');
  }

  enterUsername(username: string): void {
    cy.get(MyRetailSelectors.username).clear();
    if (username.length > 0) {
      cy.get(MyRetailSelectors.username).type(username);
    }
  }

  enterPassword(password: string): void {
    cy.get(MyRetailSelectors.password).clear();
    if (password.length > 0) {
      cy.get(MyRetailSelectors.password).type(password);
    }
  }

  clickLogin(): void {
    cy.get(MyRetailSelectors.loginButton).click();
  }

  login(username: string, password: string): void {
    const appPassword =
      password === 'password' ? (Cypress.env('appPassword') ?? password) : password;
    this.enterUsername(username);
    this.enterPassword(appPassword);
    this.clickLogin();
  }

  getErrorMessage(): Cypress.Chainable<string> {
    return cy.get(MyRetailSelectors.errorMessage).invoke('text');
  }
}
