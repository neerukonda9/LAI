// data-test selectors only — see docs/selector-strategy.md
export const MyRetailSelectors = {
  username: '[data-test="username"]',
  password: '[data-test="password"]',
  loginButton: '[data-test="login-button"]',
  errorMessage: '[data-test="error"]',
  productSort: '[data-test="product-sort-container"]',
  inventoryList: '.inventory_list',
  pageTitle: '.title',
  cartBadge: '.shopping_cart_badge',
  loginContainer: '.login_wrapper',
  inventoryItem: '.inventory_item',
  inventoryItemName: '.inventory_item_name'
} as const;
