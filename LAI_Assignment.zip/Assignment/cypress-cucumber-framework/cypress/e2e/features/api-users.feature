@feature-api @api @regression
Feature: User API Management

  @smoke @api
  Scenario: Create a new user via API using test data
    When I create a user from test data
    Then the API response status should be 201
    And the API response body should match the create user test data

  @api
  Scenario: Create a user via factory with unique data
    When I create a user from test data factory
    Then the API response status should be 201
    And the API response body should match the factory user name

  @api
  Scenario: Update an existing user via API using test data
    When I update a user from test data
    Then the API response status should be 200
    And the API response body should match the update user test data
