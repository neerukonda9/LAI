@feature-login @regression
Feature: MyRetail Login

  Background:
    Given I open the MyRetail login page

  @smoke
  Scenario: Successful login with valid credentials
    When I login with username "standard_user" and password "password"
    Then I should land on the inventory page
    And the inventory page title should be "Products"

  @test @regression
  Scenario: Failed login with locked out user
    When I login with username "locked_out_user" and password "password"
    Then I should see a login error containing "Sorry, this user has been locked out."

  @regression
  Scenario: Login validation with invalid credentials
    When I attempt login with the following invalid credentials:
      | username     | password   | expected_error                                                             |
      |              | password   | Epic sadface: Username is required                                         |
      | standard_user|            | Epic sadface: Password is required                                         |
      | invalid_user | wrong_pass | Epic sadface: Username and password do not match any user in this service  |
