@feature-sorting @regression
Feature: Product Sorting

  Background:
    Given I am logged in as "standard_user"

  Scenario Outline: Sort inventory by option
    When I sort products by "<sort_option>"
    Then the first product name should be "<first_product>"

    Examples:
      | sort_option | first_product |
      | Name (A to Z)  | Backpack |
      | Name (Z to A)  | T-Shirt |

  Scenario Outline: Filter products by price range
    When I sort products by "<sort_option>"
    Then the first product price should be "<first_price>"

    Examples:
      | sort_option        | first_price |
      | Price (low to high) | $7.99      |
      | Price (high to low) | $49.99     |
