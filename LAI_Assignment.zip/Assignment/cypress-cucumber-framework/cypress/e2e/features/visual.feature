@feature-visual @visual @regression
Feature: Visual regression

  Scenario: Login page visual snapshot
    Given I open the MyRetail login page
    Then the login page visual snapshot should be captured
