@feature-analytics @analytics @regression
Feature: Analytics event tracking

  Background:
    Given analytics tracking is enabled

  @smoke
  Scenario: Login success analytics event
    When I login with username "standard_user" and password "password"
    Then an analytics event "login_success" should be recorded

  Scenario: Add to cart analytics event
    Given I am logged in as "standard_user"
    When I add cart items from test data
    Then an analytics event "add_to_cart" should include product "Backpack"
