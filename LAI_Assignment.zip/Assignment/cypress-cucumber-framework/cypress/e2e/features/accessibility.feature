@feature-accessibility @accessibility @regression
Feature: Accessibility compliance

  @smoke
  Scenario: Login page accessibility scan
    Given I open the MyRetail login page
    Then the login page should have no critical accessibility violations

  Scenario: Inventory page accessibility scan
    Given I am logged in as "standard_user"
    Then the inventory page should have no critical accessibility violations
