# Selectors

Use `[data-test="..."]` where available. Central map: `cypress/selectors/myretail.selectors.ts`.

Page objects import selectors; step definitions call page objects only.

Class-based fallbacks exist for legacy demo markup — replace with `data-test` when the app supports it.
