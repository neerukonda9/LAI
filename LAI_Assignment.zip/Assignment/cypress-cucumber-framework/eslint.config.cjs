const eslint = require('@eslint/js');
const tseslint = require('typescript-eslint');
const prettier = require('eslint-config-prettier');
const cypress = require('eslint-plugin-cypress/flat');
const globals = require('globals');

module.exports = tseslint.config(
  {
    ignores: ['node_modules/**', 'dist/**', 'reports/**']
  },
  eslint.configs.recommended,
  ...tseslint.configs.recommended,
  prettier,
  cypress.configs.recommended,
  {
    files: ['**/*.{js,cjs}'],
    languageOptions: {
      globals: globals.node,
      sourceType: 'commonjs'
    },
    rules: {
      '@typescript-eslint/no-require-imports': 'off'
    }
  },
  {
    files: ['**/*.ts'],
    rules: {
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      '@typescript-eslint/no-explicit-any': 'warn',
      'no-console': 'off',
      'cypress/no-unnecessary-waiting': 'warn'
    }
  }
);
