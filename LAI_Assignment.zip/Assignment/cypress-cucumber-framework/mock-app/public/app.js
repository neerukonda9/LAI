const products = [
  { name: 'Backpack', price: 29.99 },
  { name: 'Bike Light', price: 9.99 },
  { name: 'Sticker', price: 7.99 },
  { name: 'T-Shirt', price: 15.99 },
  { name: 'Jacket', price: 49.99 }
];

let cartCount = 0;

const loginView = document.getElementById('login-view');
const inventoryView = document.getElementById('inventory-view');
const loginForm = document.getElementById('login-form');
const errorBox = document.getElementById('error');
const productList = document.getElementById('product-list');
const sortSelect = document.getElementById('sort');
const cartBadge = document.querySelector('.shopping_cart_badge');

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = !message;
}

function formatPrice(value) {
  return `$${value.toFixed(2)}`;
}

function sortProducts(option) {
  const sorted = [...products];
  if (option === 'Name (A to Z)') {
    sorted.sort((a, b) => a.name.localeCompare(b.name));
  } else if (option === 'Name (Z to A)') {
    sorted.sort((a, b) => b.name.localeCompare(a.name));
  } else if (option === 'Price (low to high)') {
    sorted.sort((a, b) => a.price - b.price);
  } else if (option === 'Price (high to low)') {
    sorted.sort((a, b) => b.price - a.price);
  }
  return sorted;
}

function renderProducts() {
  const sorted = sortProducts(sortSelect.value);
  productList.innerHTML = '';

  sorted.forEach((product) => {
    const row = document.createElement('div');
    row.className = 'inventory_item';

    row.innerHTML = `
      <span class="inventory_item_name">${product.name}</span>
      <span>
        <span class="inventory_item_price">${formatPrice(product.price)}</span>
        <button type="button">Add to cart</button>
      </span>
    `;

    row.querySelector('button').addEventListener('click', () => {
      cartCount += 1;
      cartBadge.textContent = String(cartCount);
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({ event: 'add_to_cart', product: product.name, source: 'myretail' });
    });

    productList.appendChild(row);
  });
}

function showInventory() {
  loginView.hidden = true;
  inventoryView.hidden = false;
  window.history.replaceState({}, '', '/inventory.html');
  renderProducts();
}

loginForm.addEventListener('submit', (event) => {
  event.preventDefault();
  showError('');

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const validPassword = window.__MOCK_VALID_PASSWORD__ || 'password';

  if (!username) {
    showError('Epic sadface: Username is required');
    return;
  }

  if (!password) {
    showError('Epic sadface: Password is required');
    return;
  }

  if (username === 'locked_out_user') {
    showError('Sorry, this user has been locked out.');
    return;
  }

  if (username === 'invalid_user' || password !== validPassword) {
    showError(
      'Epic sadface: Username and password do not match any user in this service'
    );
    return;
  }

  if (username === 'standard_user' && password === validPassword) {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: 'login_success', user: username, source: 'myretail' });
    showInventory();
    return;
  }

  showError('Epic sadface: Username and password do not match any user in this service');
});

sortSelect.addEventListener('change', renderProducts);

if (window.location.pathname.includes('inventory')) {
  showInventory();
}
