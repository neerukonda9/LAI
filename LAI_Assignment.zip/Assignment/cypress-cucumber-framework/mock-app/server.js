const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.MOCK_APP_PORT || 4173);
const PUBLIC_DIR = path.join(__dirname, 'public');
const VALID_PASSWORD = process.env.APP_PASSWORD || process.env.MOCK_APP_PASSWORD || 'password';

let nextPostId = 101;

function sendJson(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (error) {
        reject(error);
      }
    });
    req.on('error', reject);
  });
}

function handleApi(req, res, url) {
  if (req.method === 'POST' && url.pathname === '/posts') {
    return readBody(req).then((body) => {
      const id = nextPostId++;
      sendJson(res, 201, { id, title: body.title, body: body.body, userId: body.userId ?? 1 });
    });
  }

  if (req.method === 'PUT' && /^\/posts\/\d+$/.test(url.pathname)) {
    const id = Number(url.pathname.split('/').pop());
    return readBody(req).then((body) => {
      sendJson(res, 200, {
        id,
        title: body.title,
        body: body.body,
        userId: body.userId ?? 1
      });
    });
  }

  if (req.method === 'GET' && url.pathname === '/health') {
    sendJson(res, 200, { status: 'ok' });
    return Promise.resolve();
  }

  return Promise.resolve(false);
}

function serveStatic(req, res, url) {
  let filePath = url.pathname === '/' ? '/index.html' : url.pathname;
  filePath = path.normalize(filePath).replace(/^(\.\.[/\\])+/, '');
  const absolutePath = path.join(PUBLIC_DIR, filePath);

  if (!absolutePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(absolutePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }

    const ext = path.extname(absolutePath);
    const types = {
      '.html': 'text/html',
      '.js': 'application/javascript',
      '.css': 'text/css'
    };
    res.writeHead(200, { 'Content-Type': types[ext] || 'text/plain' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

  try {
    const handled = await handleApi(req, res, url);
    if (handled !== false) {
      return;
    }
  } catch {
    sendJson(res, 400, { error: 'Invalid JSON body' });
    return;
  }

  serveStatic(req, res, url);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Mock MyRetail app: http://127.0.0.1:${PORT}`);
  console.log(`Mock API (JSONPlaceholder shape): http://127.0.0.1:${PORT}/posts`);
  console.log(`Valid login password: ${VALID_PASSWORD}`);
});
