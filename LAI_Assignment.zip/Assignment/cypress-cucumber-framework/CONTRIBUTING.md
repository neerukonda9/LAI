# Contributing

## Where to add code

| Type        | Location                              |
| ----------- | ------------------------------------- |
| Feature     | `cypress/e2e/features/*.feature`      |
| Steps       | `cypress/step_definitions/*.steps.ts` |
| Page object | `cypress/pages/`                      |
| Selectors   | `cypress/selectors/`                  |
| Test data   | `cypress/fixtures/`                   |
| Factories   | `cypress/support/factories/`          |

## API vs UI separation

- **`@api` features** (`api-users.feature`): use `cy.request` only — no UI login
- **`@ui` features**: browser interactions only
- **`@api-setup`**: API seeds data in Background, then UI steps run

## Tags

See Playwright framework `CONTRIBUTING.md` for full tag list (`@smoke`, `@accessibility`, `@analytics`, etc.).

## Before opening a PR

```bash
npm run validate
npm run test:smoke
```
