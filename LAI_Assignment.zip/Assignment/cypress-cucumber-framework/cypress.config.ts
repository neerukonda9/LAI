import { defineConfig } from 'cypress';
import createBundler from '@bahmutov/cypress-esbuild-preprocessor';
import { addCucumberPreprocessorPlugin } from '@badeball/cypress-cucumber-preprocessor';
import createEsbuildPlugin from '@badeball/cypress-cucumber-preprocessor/esbuild';
import allureWriter from '@shelex/cypress-allure-plugin/writer';
import cypressOnFix from 'cypress-on-fix';

const useMockApp =
  process.env.USE_MOCK_APP === 'true' || process.env.USE_MOCK_APP === '1';
const mockAppUrl = process.env.MOCK_APP_URL ?? 'http://127.0.0.1:4173';
const stagingUrl =
  process.env.CYPRESS_BASE_URL_STAGING ?? process.env.CYPRESS_BASE_URL;

export default defineConfig({
  e2e: {
    baseUrl: useMockApp ? mockAppUrl : process.env.CYPRESS_BASE_URL,
    specPattern: 'cypress/e2e/features/**/*.feature',
    supportFile: 'cypress/support/e2e.ts',
    video: false,
    screenshotOnRunFailure: true,
    defaultCommandTimeout: 10000,
    async setupNodeEvents(on, config) {
      // Allow cucumber-preprocessor and Allure to share Cypress lifecycle hooks
      on = cypressOnFix(on);
      await addCucumberPreprocessorPlugin(on, config);
      allureWriter(on, config);

      on(
        'file:preprocessor',
        createBundler({
          plugins: [createEsbuildPlugin(config)]
        })
      );

      return config;
    }
  },
  env: {
    useMockApp,
    mockAppUrl,
    apiBaseUrl: useMockApp
      ? mockAppUrl
      : (process.env.API_BASE_URL ?? 'https://jsonplaceholder.typicode.com'),
    appPassword: useMockApp
      ? (process.env.CYPRESS_APP_PASSWORD ?? 'password')
      : process.env.CYPRESS_APP_PASSWORD,
    testEnv: process.env.TEST_ENV ?? 'staging',
    baseUrlDev: process.env.CYPRESS_BASE_URL_DEV,
    baseUrlStaging: useMockApp ? mockAppUrl : stagingUrl,
    baseUrlProd: process.env.CYPRESS_BASE_URL_PROD,
    allure: true,
    allureResultsPath: 'reports/allure-results',
    allureAttachRequests: true,
    allureLogCypress: true
  }
});
