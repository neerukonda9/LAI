# Cypress Cucumber Framework

TypeScript BDD tests with Cypress, Cucumber, and Page Object Model. UI targets MyRetail; API tests use JSONPlaceholder.

![Architecture](docs/architecture.png)

## Setup

```bash
npm install
npx cypress install
cp .env.example .env
```

### Run without a real app (mock mode)

No `CYPRESS_BASE_URL` or password needed. A local mock server serves MyRetail UI and JSONPlaceholder-shaped API responses.

#### Auto-start (recommended)

`test:mock` and `test:mock:smoke` **do not require you to start the mock server first**. They use `scripts/run-with-mock.js`, which:

1. Starts `mock-app/server.js` on `http://127.0.0.1:4173`
2. Waits for `GET /health` to respond
3. Runs tests with `USE_MOCK_APP=true` and password `password`
4. Stops the mock server when tests finish (pass or fail)

```bash
npm run test:mock:smoke   # auto-start mock → @smoke → auto-stop
npm run test:mock         # auto-start mock → full suite → auto-stop
```

#### Manual start (debugging)

Start the mock server yourself when you want to inspect the app in a browser, re-run tests without restarting the server, or use the regular test commands.

**Terminal 1 — keep running**

```bash
npm run mock:server
```

Open `http://127.0.0.1:4173` in a browser. Mock login: `standard_user` / `password`.

**Terminal 2 — run tests against the running mock**

Copy `.env.example` to `.env` and set:

```bash
USE_MOCK_APP=true
MOCK_APP_URL=http://127.0.0.1:4173
CYPRESS_APP_PASSWORD=password
```

Then run any command that does **not** use `test:mock` (those would try to start a second server on the same port):

```bash
npm run test:smoke
npm run test:regression
npm test
```

To use a different port: `MOCK_APP_PORT=4174 npm run mock:server` and set `MOCK_APP_URL=http://127.0.0.1:4174` in `.env`.

Mock behaviour and user rules: `mock-app/public/app.js`.

### Real app credentials

When `USE_MOCK_APP` is false or unset:

| Variable                                        | Notes                                            |
| ----------------------------------------------- | ------------------------------------------------ |
| `TEST_ENV`                                      | `dev`, `staging`, or `prod` (default: `staging`) |
| `CYPRESS_BASE_URL` / `CYPRESS_BASE_URL_STAGING` | App URL                                          |
| `CYPRESS_BASE_URL_DEV`, `CYPRESS_BASE_URL_PROD` | Optional tier URLs                               |
| `CYPRESS_APP_PASSWORD`                          | Login password                                   |
| `API_BASE_URL`                                  | JSONPlaceholder for `@api` tests                 |

Env validation runs in `cypress/support/e2e.ts` before specs.

Pre-commit: repo root `.husky/pre-commit` runs lint-staged on changed files in this folder.

## Commands

| Command                      | Purpose                                   |
| ---------------------------- | ----------------------------------------- |
| `npm test`                   | Full suite                                |
| `npm run test:mock:smoke`    | Auto-start mock, run `@smoke`, auto-stop (no manual server) |
| `npm run test:mock`          | Auto-start mock, full suite, auto-stop                      |
| `npm run mock:server`        | Mock only — use for debugging (see Setup above)             |
| `npm run test:smoke`         | `@smoke` only                               |
| `npm run test:regression`    | `@regression`                             |
| `npm run test:parallel`      | One Cypress process per feature           |
| `npm run test:report`        | Tests + Cucumber HTML + metrics           |
| `npm run test:allure`        | Tests + Allure + metrics                  |
| `npm run test:notify`        | Tests + report + Slack                    |
| `npm run test:browserstack`  | BrowserStack device farm                  |
| `npm run test:report:zephyr` | Tests + report + JIRA upload              |
| `npm run validate`           | typecheck, ESLint, gherkin-lint, Prettier |
| `npm run metrics`            | Write `reports/test-metrics.json`         |
| `npm run audit:check`        | npm audit (high severity)                 |

## Feature files

| File                      | Tags                        | Notes                         |
| ------------------------- | --------------------------- | ----------------------------- |
| `login.feature`           | `@feature-login`            | Explicit login for pass/fail  |
| `product-sorting.feature` | `@feature-sorting`          | Composite login in Background |
| `api-users.feature`       | `@feature-api`, `@api`      | API only + factory scenario   |
| `inventory-ui.feature`    | `@ui`, `@api-setup`         | API seed, then UI             |
| `accessibility.feature`   | `@accessibility`, `@visual` | cypress-axe + screenshot      |
| `analytics.feature`       | `@analytics`                | dataLayer events              |

## Login steps

| Use case                  | Step                                                       |
| ------------------------- | ---------------------------------------------------------- |
| Login test (pass or fail) | `When I login with username "..." and password "password"` |
| Already logged in         | `Given I am logged in as "standard_user"`                  |
| Invalid credentials       | `When I attempt login with the following invalid credentials:` + data table |

Locked-out user:

```gherkin
When I login with username "locked_out_user" and password "password"
Then I should see a login error containing "Sorry, this user has been locked out."
```

## Tags

| Tag              | CI usage                  |
| ---------------- | ------------------------- |
| `@smoke`         | PR pipeline               |
| `@regression`    | Nightly / release         |
| `@api`           | API only                  |
| `@ui`            | UI only                   |
| `@api-setup`     | API precondition, then UI |
| `@accessibility` | axe scan                  |
| `@analytics`     | dataLayer checks          |
| `@visual`        | Screenshot to Allure      |
| `@feature-*`     | Domain grouping           |

## Test data

| Path                                        | Contents                              |
| ------------------------------------------- | ------------------------------------- |
| `cypress/fixtures/users.json`               | Valid user, locked user, invalid rows |
| `cypress/fixtures/products.json`            | Cart items, sort data                 |
| `cypress/fixtures/api-users.json`           | API payloads                          |
| `cypress/support/factories/user.factory.ts` | Unique user per run                   |

Helpers: `cypress/support/test-data.ts`, `cy.fixture()`.

## Selectors

`cypress/selectors/myretail.selectors.ts` — page objects import from here. See `docs/selector-strategy.md`.

## API vs UI

- **`@api`**: `cy.request` / `UserApiPage` — no UI login.
- **`@ui`**: Browser interactions only.
- **`@api-setup`**: POST to JSONPlaceholder in Background, then UI steps.

## Accessibility and analytics

- **Accessibility**: `cypress-axe` — `@accessibility` scenarios on login and inventory.
- **Analytics**: `cypress/support/analytics-helper.ts` tracks `dataLayer` on login and add-to-cart.
- **Visual**: `@visual` captures login screenshot (Allure artifact).

## Reports

| Output        | Path                           |
| ------------- | ------------------------------ |
| Cucumber HTML | `reports/html/index.html`      |
| Cucumber JSON | `reports/cucumber-report.json` |
| Allure        | `reports/allure-report/`       |
| Metrics       | `reports/test-metrics.json`    |
| Slack         | `npm run notify:slack`         |

## Code quality

- `eslint.config.cjs` — TS + Cypress rules
- `.gherkin-lintrc` — feature file rules
- `.prettierrc.json` — formatting
- `.nvmrc` — Node 20

```bash
npm run validate
```

## CI/CD

```
PR      → validate + test:smoke
Nightly → test:parallel + allure:report + metrics + Slack
Release → test:browserstack + upload:zephyr (tag: cypress-v*)
```

Workflows (repo root):

| Workflow | File                                                                                |
| -------- | ----------------------------------------------------------------------------------- |
| PR       | [`.github/workflows/cypress-pr.yml`](../.github/workflows/cypress-pr.yml)           |
| Nightly  | [`.github/workflows/cypress-nightly.yml`](../.github/workflows/cypress-nightly.yml) |
| Release  | [`.github/workflows/cypress-release.yml`](../.github/workflows/cypress-release.yml) |
| Security | [`.github/workflows/security-scan.yml`](../.github/workflows/security-scan.yml)     |

GitHub secrets: `CYPRESS_BASE_URL`, `CYPRESS_APP_PASSWORD`, `SLACK_WEBHOOK_URL`, `BROWSERSTACK_*`, `ZEPHYR_API_TOKEN`.

Dependabot: [`.github/dependabot.yml`](../.github/dependabot.yml). Gitleaks: `.gitleaks.toml`.

## JIRA / BrowserStack

```bash
npm run test:report:zephyr
npm run test:browserstack
```

`config/zephyr-map.json` maps scenario names to test case keys. `browserstack.json` defines device matrix.

## Project layout

```
cypress/e2e/features/
cypress/fixtures/
cypress/pages/
cypress/selectors/
cypress/step_definitions/
cypress/support/
scripts/
mock-app/
config/
docs/
browserstack.json
```

Interview prep guide: [`docs/INTERVIEW-GUIDE.md`](../docs/INTERVIEW-GUIDE.md)

See [CONTRIBUTING.md](CONTRIBUTING.md).

## Technology stack

- **Language / runtime**: TypeScript 5, Node.js 20
- **Test runner**: Cypress 14 — E2E and `cy.request` API tests
- **BDD**: `@badeball/cypress-cucumber-preprocessor` with esbuild
- **Page objects**: custom POM under `cypress/pages/` + `cypress/selectors/`
- **Mock app**: Node `http` server in `mock-app/` for offline/CI runs
- **Reporting**: `multiple-cucumber-html-reporter`, Allure (`@shelex/cypress-allure-plugin`)
- **Accessibility**: `cypress-axe` / `axe-core`
- **Analytics**: custom `dataLayer` helper
- **Lint / format**: ESLint 9, Prettier, gherkin-lint
- **Git hooks**: Husky + lint-staged (repo root)
- **CI/CD**: GitHub Actions
- **Security**: Gitleaks, Dependabot, `npm audit`
- **Optional**: BrowserStack, Zephyr Scale, Slack webhook
